/*
 * Implementation file for simple MapReduce framework.  Fill in the functions
 * and definitions in this file to complete the assignment.
 *
 * Place all of your implementation code in this file.  You are encouraged to
 * create helper functions wherever it is necessary or will make your code
 * clearer.  For these functions, you should follow the practice of declaring
 * them "static" and not including them in the header file (which should only be
 * used for the *public-facing* API.
 */


/* Header includes */
#include <stdlib.h>
#include <stdio.h>
#include <errno.h>
#include <string.h>
#include <unistd.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <pthread.h>
#include "mapreduce.h"


/* Size of shared memory buffers */
#define MR_BUFFER_SIZE 1024

//the path is for creating thread
void pathmap (void* path){
//this is only here for thread requirement 
}
//the path for reducing thread
void pathreduce (void* path){
//this is only here for thread requirement
}

/* Allocates and initializes an instance of the MapReduce framework */
struct map_reduce *mr_create(map_fn map, reduce_fn reduce, int threads)
{
	// allocate space for whole map reduce structure
	struct map_reduce *mr = (struct map_reduce *)malloc(sizeof(struct map_reduce));
	//if fail
	if (mr==NULL){	return NULL;}


	// pointers pointing to kvpairs for the buffers
	mr->buff = (char *)malloc(MR_BUFFER_SIZE*sizeof(char));
	if(mr->buff==NULL){return NULL;}

	// counter in order to check if the buffer is already full
	mr->count = (int *)malloc((threads+1)*sizeof(int));
	if(mr->count==NULL){return NULL;}

	// threads and its count
	mr->t = (pthread_t *)malloc((threads+1)*sizeof(pthread_t));
	if(mr->t==NULL){return NULL;}
	
	mr->map= (map_fn*)malloc(threads*sizeof(map_fn));
	if(mr->map==NULL){return NULL;}
	
//	mr->reduce= (reduce_fn*)malloc(sizeof(reduce_fn));
//	if(mr->reduce==NULL){return NULL;}
	
	//for the files
	mr->infile= (FILE **)malloc(threads*sizeof(FILE));
	if(mr->infile==NULL){return NULL;}
	
	mr->outfile= (FILE *)malloc(sizeof(FILE));
	if(mr->outfile==NULL){return NULL;}
	
	// map and reduce	
	int i=0;
	for (i=0;i<threads;i++){
	mr->map[i]=map;
	}
	mr->reduce=reduce;	
	
	return mr;	
}

/* Destroys and cleans up an existing instance of the MapReduce framework */
void mr_destroy(struct map_reduce *mr)
{
	free(mr->buff);
	free(mr->count);
	free(mr->t);
	free(mr->infile);
	free(mr->outfile);
	free(mr->map);
	free(mr);

}

/* Begins a multithreaded MapReduce operation */
int mr_start(struct map_reduce *mr, const char *inpath, const char *outpath)
{
/*	int i;

	for (i = 0; i < mr->map->nmap; i++) {
		mr->infile=fopen(inpath, "r");
		//since each thread should have a different open file, open every single time
		//create thread for fuction path map
		pthread_create(1, NULL, pathmap, (void *)mr);
		map(mr, mr->infile, i, i+1);
	}
	//output file
	mr->outfile=fopen(outpath, "w");
	
	//create thread for function pathreduce
	pthread_create(1, NULL, pathreduce, (void *)mr);
	reduce(pathreduce, pathreduce->outfile, pathreduce->tott);
*/
	return 0;

}

/* Blocks until the entire MapReduce operation is complete */
int mr_finish(struct map_reduce *mr)
{
/*	int i, j=0;

	for (i = 0; i < mr->map->nmap; i++) {
		if(mr->t[i]!=NULL){
			j+=1;
		}
	}

	//if all are finished
	if (j==0){
	return 0;
	}
*/
	//if not	
	return 1;  
}

/* Called by the Map function each time it produces a key-value pair */
int mr_produce(struct map_reduce *mr, int id, const struct kvpair *kv)
{
	// wait to attain the lock
//	pthread_mutex_lock(&(mr->lock[id]));

	// block on conditional variable
//	while (mr->count[id] == MR_BUFFER_SIZE)
//		pthread_cond_wait(&(mr->notfull[id]), &(mr->lock[id]));

	// add item to buffer
//	mr->buffer[id*MR_BUFFER_SIZE + mr->in[id]] = *kv;
	
	// increment the count and in index
//	mr->in[id] = (mr->in[id] + 1) % MR_BUFFER_SIZE;
//	(mr->count[id])++;

	// signal that the buffer is not empty
//	pthread_cond_signal(&(mr->notempty[id]));
	// release the lock
//	pthread_mutex_unlock(&(mr->lock[id]));

	// CHECK WHEN TO RETURN -1 FOR ERROR

	// return 1 for success
//	return 1;

	return 0;
}

/* Called by the Reduce function to consume a key-value pair */
int mr_consume(struct map_reduce *mr, int id, struct kvpair *kv)
{
	// wait to attain the lock
//	pthread_mutex_lock(&(mr->lock[id]));

	// conditional wait for buffer to be non-empty and for lock
//	while (mr->count[id] == 0)
//		pthread_cond_wait(&(mr->notempty[id]), &(mr->lock[id]));
	
	// increment the count and out index
//	mr->out[id] = (mr->out[id] + 1) % MR_BUFFER_SIZE;
//	(mr->count[id])--;

	// signal that the buffer is not full
///	pthread_cond_signal(&(mr->notfull[id]));
	// release the lock
//	pthread_mutex_unlock(&(mr->lock[id]));

	// CHECK WHEN TO RETURN 0

	// CHECK WHEN TO RETURN -1

	// return success
//	return 1;

	return 0;
}
